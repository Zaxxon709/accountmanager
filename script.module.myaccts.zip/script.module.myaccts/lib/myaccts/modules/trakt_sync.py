import xbmc, xbmcaddon, xbmcgui
import os
import xbmcvfs
from pathlib import Path
from myaccts.modules import control

check_myaccts = xbmcaddon.Addon('script.module.myaccts').getSetting("trakt.token")

#Seren Trakt
def seren_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.seren/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':
                
                client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/resources/lib/indexers/trakt.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                new_client = data.replace(f'0c9a30819e4af6ffaf3b954cbeae9b54499088513863c03c02911de00ac2de79',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                new_secret = data.replace(f'bf02417f27b514cee6a8d135f2ddc261a15eecfb6ed6289c36239826dcdd1842',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.seren")

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.auth", your_token)

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt.username", your_username)
                
                your_refresh = myaccts.getSetting("trakt.refresh")
                addon.setSetting("trakt.refresh", your_refresh)
                
                your_expires = myaccts.getSetting("trakt.expires")
                your_expires_float = float(your_expires)
                your_expires_rnd = int(your_expires_float)
                your_expires_str = str(your_expires_rnd)
                addon.setSetting("trakt.expires", your_expires_str)

#Fen
def fen_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.fen/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/resources/lib/apis/trakt_api.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                new_client = data.replace(f'645b0f46df29d27e63c4a8d5fff158edd0bef0a6a5d32fc12c1b82388be351af',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                new_secret = data.replace(f'422a282ef5fe4b5c47bc60425c009ac3047ebd10a7f6af790303875419f18f98',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.fen")

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.token", your_token)

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt.user", your_username)
                
                your_refresh = myaccts.getSetting("trakt.refresh")
                addon.setSetting("trakt.refresh", your_refresh)

                your_expires = myaccts.getSetting("trakt.expires")
                addon.setSetting("trakt.expires", your_expires)

                addon.setSetting("trakt.indicators_active", 'true')
                addon.setSetting("watched.indicators", '1')

#Ezra
def ezra_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.ezra/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ezra/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.ezra")

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.token", your_token)

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt_user", your_username)
                
                your_expires = myaccts.getSetting("trakt.expires")
                addon.setSetting("trakt.expires", your_expires)
                
#POV
def pov_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.pov/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/resources/lib/apis/trakt_api.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                new_client = data.replace(f'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                new_secret = data.replace(f'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.pov")

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.token", your_token)

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt_user", your_username)
                
                your_refresh = myaccts.getSetting("trakt.refresh")
                addon.setSetting("trakt.refresh", your_refresh)

                your_expires = myaccts.getSetting("trakt.expires")
                addon.setSetting("trakt.expires", your_expires)

                addon.setSetting("trakt.indicators_active", 'true')
                addon.setSetting("watched.indicators", '1')              

#Umbrella
def umb_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.umbrella/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/resources/lib/modules/trakt.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                new_client = data.replace(f'87e3f055fc4d8fcfd96e61a47463327ca877c51e8597b448e132611c5a677b13',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                new_secret = data.replace(f'4a1957a52d5feb98fafde53193e51f692fa9bdcd0cc13cf44a5e39975539edf0',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.umbrella")

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt.user.name", your_username)

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.user.token", your_token)

                your_refresh = myaccts.getSetting("trakt.refresh")
                addon.setSetting("trakt.refreshtoken", your_refresh)

                your_secret = myaccts.getSetting("trakt.expires")
                addon.setSetting("trakt.token.expires", your_secret)
                
#Homelander
def home_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.homelander/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/resources/lib/modules/trakt.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                new_client = data.replace(f'api_keys.trakt_client_id',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.homelander")

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt.user", your_username)

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.token", your_token)

                your_refresh = myaccts.getSetting("trakt.refresh")
                addon.setSetting("trakt.refresh", your_refresh)

                addon.setSetting("trakt.authed", 'yes')

#The Crew
def crew_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.thecrew/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.thecrew/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/script.module.thecrew/lib/resources/lib/modules/trakt.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                new_client = data.replace(f'482f9db52ee2611099ce3aa1abf9b0f7ed893c6d3c6b5face95164eac7b01f71',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                new_secret = data.replace(f'80a2729728b53ba1cc38137b22f21f34d590edd35454466c4b8920956513d967',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.thecrew")

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt.user", your_username)

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.token", your_token)

                your_refresh = myaccts.getSetting("trakt.refresh")
                addon.setSetting("trakt.refresh", your_refresh)

#Shazam
def shazam_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.shazam/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/resources/lib/modules/trakt.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                new_client = data.replace(f'api_keys.trakt_client_id',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.shazam")

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt.user", your_username)

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.token", your_token)

                your_refresh = myaccts.getSetting("trakt.refresh")
                addon.setSetting("trakt.refresh", your_refresh)

                addon.setSetting("trakt.authed", 'yes')

#Nightwing
def night_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.nightwing/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/resources/lib/modules/trakt.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                new_client = data.replace(f'base64.b64decode("MjFiODhkNGRjZDU4ZjVlY2EzOTEyOGE3MzZkMjIxNmRhNTZiNTIxMTQ4MDUyNThjNGU5ZjlhNjNkOTgwMDcyMg==")',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                new_secret = data.replace(f'base64.b64decode("MjM4OGIzMDdkZDFiYTU0NGQ2ZmEwZTFmNTcxNDczNWJkNTIwYzhmZTM4ZGYyMTEyZDg4ODg1MmJhODE1YWRlOQ==")',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()
                
                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.nightwing")

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt.user", your_username)

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.token", your_token)

                your_refresh = myaccts.getSetting("trakt.refresh")
                addon.setSetting("trakt.refresh", your_refresh)

                addon.setSetting("trakt.authed", 'yes')

#The Promise
def promise_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.thepromise/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.thepromise/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.thepromise/resources/lib/modules/trakt.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                new_client = data.replace(f'api_keys.trakt_client_id',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.thepromise")

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt.user", your_username)

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.token", your_token)

                your_refresh = myaccts.getSetting("trakt.refresh")
                addon.setSetting("trakt.refresh", your_refresh)

                addon.setSetting("trakt.authed", 'yes')

#Scrubs V2
def scrubs_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.scrubsv2/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.scrubsv2/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.scrubsv2/resources/lib/modules/trakt.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                new_client = data.replace(f'63c53edc299b7a05cc6ea2272e8a84e13aade067c18a794362ab9a4a84eafb16',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                new_secret = data.replace(f'9163ebda9d33acd06c74d017e861404b7212ee34675e09e73365d7536b84eab6',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.scrubsv2")

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt.user", your_username)

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.token", your_token)

                your_refresh = myaccts.getSetting("trakt.refresh")
                addon.setSetting("trakt.refresh", your_refresh)

                addon.setSetting("trakt.authed", 'yes')

#Alvin
def alvin_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.alvin/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.alvin/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.alvin/resources/lib/modules/trakt.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                new_client = data.replace(f'api_keys.trakt_client_id',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.alvin")

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt.user", your_username)

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.token", your_token)

                your_refresh = myaccts.getSetting("trakt.refresh")
                addon.setSetting("trakt.refresh", your_refresh)

                addon.setSetting("trakt.authed", 'yes')

#My Accounts
def myacts_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/script.module.myaccounts/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/script.module.myaccounts/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/script.module.myaccounts/lib/myaccounts/modules/trakt.py')

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                new_client = data.replace(f'e3a8d1c673dfecb7f669b23ecbf77c75fcfd24d3e8c3dbc7f79ed995262fa1db',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                new_secret = data.replace(f'73bee6aeee29cb75db4d8771458a440017f7cfe842e85f457ed9d81f7910b349',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("script.module.myaccounts")

                your_token = myaccts.getSetting("trakt.token")
                addon.setSetting("trakt.token", your_token)

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("trakt.username", your_username)
                
                your_expires = myaccts.getSetting("trakt.expires")
                addon.setSetting("trakt.expires", your_expires)

#TMDB Helper
def tmdbh_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/plugin.video.themoviedb.helper/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.themoviedb.helper/resources/tmdbhelper/lib/api/api_keys/trakt.py')
                
                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                new_client = data.replace(f'e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                new_secret = data.replace(f'15119384341d9a61c751d8d515acbc0dd801001d4ebe85d3eef9885df80ee4d9',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("plugin.video.themoviedb.helper")

                your_token = myaccts.getSetting("trakt.token")
                your_refresh = myaccts.getSetting("trakt.refresh")
                your_expires = myaccts.getSetting("trakt.expires")
                your_expires_float = float(your_expires)
                your_expires_rnd = int(your_expires_float)

                token = '{"access_token":"'
                refresh = f'","token_type":"bearer","expires_in":7776000,"refresh_token":"'
                expires = f'","scope":"public","created_at":'
                tmdbh_data = '%s%s%s%s%s%s}' %(token,your_token,refresh,your_refresh,expires,your_expires_rnd)
                addon.setSettingString("Trakt_token", tmdbh_data)


#Trakt Addon
def trakt_trakt():

        addon_inst = xbmcvfs.translatePath('special://home/addons/script.trakt/')
        file = xbmcvfs.translatePath('special://userdata/addon_data/script.trakt/settings.xml')

        if xbmcvfs.exists(addon_inst) and xbmcvfs.exists(file) and str(check_myaccts) != '':

                client_keys = xbmcvfs.translatePath('special://home/addons/script.trakt/resources/lib/traktapi.py')
                
                f = open(client_keys,'r')
                data = f.read()
                f.close()
                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                new_client = data.replace(f'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868',client)
                f = open(client_keys,'w')
                f.write(new_client)
                f.close()

                f = open(client_keys,'r')
                data = f.read()
                f.close()
                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                new_secret = data.replace(f'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0',secret)
                f = open(client_keys,'w')
                f.write(new_secret)
                f.close()

                myaccts = xbmcaddon.Addon("script.module.myaccts")
                addon = xbmcaddon.Addon("script.trakt")

                your_username = myaccts.getSetting("trakt.username")
                addon.setSetting("user", your_username)
                
                your_token = myaccts.getSetting("trakt.token")
                your_refresh = myaccts.getSetting("trakt.refresh")
                your_expires = myaccts.getSetting("trakt.expires")
                your_expires_float = float(your_expires)
                your_expires_rnd = int(your_expires_float)
                
                token = '{"access_token": "'
                refresh = f'","token_type": "bearer", "expires_in": 7776000, "refresh_token": "'
                expires = f'", "scope": "public", "created_at": '
                trakt_data = '%s%s%s%s%s%s}' %(token, your_token, refresh, your_refresh, expires, your_expires_rnd)
                addon.setSetting("authorization", trakt_data)

def sync_all():
        if str(check_myaccts) != '':
                seren_trakt()
                fen_trakt()
                pov_trakt()
                ezra_trakt()
                umb_trakt()
                home_trakt()
                crew_trakt()
                shazam_trakt()
                night_trakt()
                promise_trakt()
                scrubs_trakt()
                alvin_trakt()
                myacts_trakt()
                tmdbh_trakt()
                trakt_trakt()
