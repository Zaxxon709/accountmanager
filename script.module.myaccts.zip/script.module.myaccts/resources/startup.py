import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import os.path
import time

joinPath = os.path.join
dialog = xbmcgui.Dialog()
addon = xbmcaddon.Addon
addonObject = addon('script.module.myaccts')
addonInfo = addonObject.getAddonInfo
rd_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.myaccts').getAddonInfo('path'), 'resources', 'icons'), 'realdebrid.png')
pm_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.myaccts').getAddonInfo('path'), 'resources', 'icons'), 'premiumize.png')
ad_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.myaccts').getAddonInfo('path'), 'resources', 'icons'), 'alldebrid.png')

timeout_start = time.time()
timeout = 60*5 #Time out 5min from now

def notification(title=None, message=None, icon=None, time=3000, sound=False):
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)
	if icon is None or icon == '' or icon == 'default': icon = addonIcon()
	elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
	elif icon == 'WARNING': icon = xbmcgui.NOTIFICATION_WARNING
	elif icon == 'ERROR': icon = xbmcgui.NOTIFICATION_ERROR
	dialog.notification(heading, body, icon, time, sound=sound)

def addonIcon():
	return addonInfo('icon')

def addonName():
	return addonInfo('name')


def api_check():

        check_api = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        check_myaccts = xbmcaddon.Addon('script.module.myaccts').getSetting("trakt.token")

        check_addon_seren = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/')
        check_addon_fen = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/')
        check_addon_pov = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')
        check_addon_umb = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/')
        check_addon_home = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/')
        check_addon_crew = xbmcvfs.translatePath('special://home/addons/plugin.video.thecrew/')
        check_addon_shazam = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/')
        check_addon_night = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/')
        check_addon_promise = xbmcvfs.translatePath('special://home/addons/plugin.video.thepromise/')
        check_addon_tmdbh = xbmcvfs.translatePath('special://home/addons/plugin.video.themoviedb.helper/')
        check_addon_trakt = xbmcvfs.translatePath('special://home/addons/script.trakt/')
        
        client_keys_seren = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/resources/lib/indexers/trakt.py')
        client_keys_fen = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/resources/lib/apis/trakt_api.py')
        client_keys_pov = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/resources/lib/apis/trakt_api.py')
        client_keys_umb = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/resources/lib/modules/trakt.py')
        client_keys_home = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/resources/lib/modules/trakt.py')
        client_keys_crew = xbmcvfs.translatePath('special://home/addons/script.module.thecrew/lib/resources/lib/modules/trakt.py')
        client_keys_shazam = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/resources/lib/modules/trakt.py')
        client_keys_night = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/resources/lib/modules/trakt.py')
        client_keys_home = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/resources/lib/modules/trakt.py')
        client_keys_promise = xbmcvfs.translatePath('special://home/addons/plugin.video.thepromise/resources/lib/modules/trakt.py')
        client_keys_tmdbh = xbmcvfs.translatePath('special://home/addons/plugin.video.themoviedb.helper/resources/tmdbhelper/lib/api/api_keys/trakt.py')
        client_keys_trakt = xbmcvfs.translatePath('special://home/addons/script.trakt/resources/lib/traktapi.py')
        
        while True:

                if time.time() > timeout_start + timeout:
                        break
        
                if xbmcvfs.exists(check_addon_seren) and str(check_myaccts) != '':
                        check_seren = xbmcaddon.Addon('plugin.video.seren').getSetting("trakt.auth")
                        if str(check_seren) != '':
                                with open(client_keys_seren) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_seren,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'0c9a30819e4af6ffaf3b954cbeae9b54499088513863c03c02911de00ac2de79',client)
                                                f = open(client_keys_seren,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_seren,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'bf02417f27b514cee6a8d135f2ddc261a15eecfb6ed6289c36239826dcdd1842',secret)
                                                f = open(client_keys_seren,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
              
                if xbmcvfs.exists(check_addon_fen) and str(check_myaccts) != '':
                        check_fen = xbmcaddon.Addon('plugin.video.fen').getSetting("trakt.token")
                        if str(check_fen) != '':
                                with open(client_keys_fen) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_fen,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'645b0f46df29d27e63c4a8d5fff158edd0bef0a6a5d32fc12c1b82388be351af',client)
                                                f = open(client_keys_fen,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_fen,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'422a282ef5fe4b5c47bc60425c009ac3047ebd10a7f6af790303875419f18f98',secret)
                                                f = open(client_keys_fen,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
         
                if xbmcvfs.exists(check_addon_pov) and str(check_myaccts) != '':
                        check_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("trakt.token")
                        if str(check_pov) != '':
                                with open(client_keys_pov) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_pov,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868',client)
                                                f = open(client_keys_pov,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_pov,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0',secret)
                                                f = open(client_keys_pov,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
                                        
                if xbmcvfs.exists(check_addon_umb) and str(check_myaccts) != '':
                        check_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("trakt.user.token")
                        if str(check_umb) != '':
                                with open(client_keys_umb) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_umb,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'87e3f055fc4d8fcfd96e61a47463327ca877c51e8597b448e132611c5a677b13',client)
                                                f = open(client_keys_umb,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_umb,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'4a1957a52d5feb98fafde53193e51f692fa9bdcd0cc13cf44a5e39975539edf0',secret)
                                                f = open(client_keys_umb,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
                                        
                if xbmcvfs.exists(check_addon_home) and str(check_myaccts) != '':
                        check_home = xbmcaddon.Addon('plugin.video.homelander').getSetting("trakt.token")
                        if str(check_home) != '':
                                with open(client_keys_home) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_home,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'api_keys.trakt_client_id',client)
                                                f = open(client_keys_home,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_home,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                                                f = open(client_keys_home,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_crew) and str(check_myaccts) != '':
                        check_crew = xbmcaddon.Addon('plugin.video.thecrew').getSetting("trakt.token")
                        if str(check_crew) != '':
                                with open(client_keys_crew) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_crew,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'482f9db52ee2611099ce3aa1abf9b0f7ed893c6d3c6b5face95164eac7b01f71',client)
                                                f = open(client_keys_crew,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_crew,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'80a2729728b53ba1cc38137b22f21f34d590edd35454466c4b8920956513d967',secret)
                                                f = open(client_keys_crew,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
                                        
                if xbmcvfs.exists(check_addon_shazam) and str(check_myaccts) != '':
                        check_shazam = xbmcaddon.Addon('plugin.video.shazam').getSetting("trakt.token")
                        if str(check_shazam) != '':
                                with open(client_keys_shazam) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_shazam,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'api_keys.trakt_client_id',client)
                                                f = open(client_keys_shazam,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_shazam,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                                                f = open(client_keys_shazam,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
                                        
                if xbmcvfs.exists(check_addon_night) and str(check_myaccts) != '':
                        check_night = xbmcaddon.Addon('plugin.video.nightwing').getSetting("trakt.token")
                        if str(check_night) != '':
                                with open(client_keys_night) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_night,'r')
                                                data = f.read()
                                                f.close()
                                                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                                                new_client = data.replace(f'base64.b64decode("MjFiODhkNGRjZDU4ZjVlY2EzOTEyOGE3MzZkMjIxNmRhNTZiNTIxMTQ4MDUyNThjNGU5ZjlhNjNkOTgwMDcyMg==")',client)
                                                f = open(client_keys_night,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_night,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                                                new_secret = data.replace(f'base64.b64decode("MjM4OGIzMDdkZDFiYTU0NGQ2ZmEwZTFmNTcxNDczNWJkNTIwYzhmZTM4ZGYyMTEyZDg4ODg1MmJhODE1YWRlOQ==")',secret)
                                                f = open(client_keys_night,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_promise) and str(check_myaccts) != '':
                        check_promise = xbmcaddon.Addon('plugin.video.thepromise').getSetting("trakt.token")
                        if str(check_promise) != '':
                                with open(client_keys_promise) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_promise,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'api_keys.trakt_client_id',client)
                                                f = open(client_keys_promise,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_promise,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                                                f = open(client_keys_promise,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_tmdbh) and str(check_myaccts) != '':
                        check_tmdbh = xbmcaddon.Addon('plugin.video.themoviedb.helper').getSetting("Trakt_token")
                        if str(check_tmdbh) != '':
                                with open(client_keys_tmdbh) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_tmdbh,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467',client)
                                                f = open(client_keys_tmdbh,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_tmdbh,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'15119384341d9a61c751d8d515acbc0dd801001d4ebe85d3eef9885df80ee4d9',secret)
                                                f = open(client_keys_tmdbh,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_trakt) and str(check_myaccts) != '':
                        check_trakt = xbmcaddon.Addon('script.trakt').getSetting("authorization")
                        if str(check_trakt) != '':
                                with open(client_keys_trakt) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_trakt,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868',client)
                                                f = open(client_keys_trakt,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_trakt,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0',secret)
                                                f = open(client_keys_trakt,'w')
                                                f.write(new_secret)
                                                f.close()
                                                pass


                xbmc.sleep(30000)

api_check()
