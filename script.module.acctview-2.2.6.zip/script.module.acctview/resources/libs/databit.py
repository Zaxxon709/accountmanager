import xbmc, xbmcaddon
import sqlite3
import xbmcvfs
import os
from resources.libs.common import var
from sqlite3 import Error

char_remov = ["'", ",", ")","("]

#Connect to database
def create_conn(db_file):
    try:
        conn = None
        try:
            conn = sqlite3.connect(db_file)
        except Error as e:
            print(e)

        return conn
    except:
        pass

#Fen Light RD   
def connect_fenlt_rd(conn, setting):
    try:
        # Update settings database
        rd_enable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        rd_token = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        rd_account_id = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        rd_client_id = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        rd_refresh = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        rd_secret = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(rd_enable, setting)
        cur.execute(rd_token, setting)
        cur.execute(rd_account_id, setting)
        cur.execute(rd_client_id, setting)
        cur.execute(rd_refresh, setting)
        cur.execute(rd_secret, setting)
        conn.commit()
        cur.close()
    except:
        pass

#Restore RD
def restore_fenlt_rd():
    try:
        conn_p = create_conn(var.rd_backup_fenlt)
        conn_t = create_conn(var.fenlt_settings_db)

        cur_p = conn_p.cursor()
        cur_t = conn_t.cursor()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('rd.enabled',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'rd.enabled',))

        conn_t.commit()
        
        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('rd.token',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'rd.token',))

        conn_t.commit()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('rd.account_id',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'rd.account_id',))

        conn_t.commit()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('rd.client_id',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'rd.client_id',))

        conn_t.commit()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('rd.refresh',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'rd.refresh',))

        conn_t.commit()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('rd.secret',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'rd.secret',))

        conn_t.commit()
        cur_t.close()
        cur_p.close()
    except:
        pass
    
#Revoke RD
def revoke_fenlt_rd():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            connect_fenlt_rd(conn, ('empty_setting', 'rd.enabled'))
            connect_fenlt_rd(conn, ('empty_setting', 'rd.token'))
            connect_fenlt_rd(conn, ('empty_setting', 'rd.account_id'))
            connect_fenlt_rd(conn, ('empty_setting', 'rd.client_id'))
            connect_fenlt_rd(conn, ('empty_setting', 'rd.refresh'))
            connect_fenlt_rd(conn, ('empty_setting', 'rd.secret'))
    except:
        pass

#Backup RD
def backup_fenlt_rd():
    if os.path.exists(os.path.join(var.fenlt_settings_db)) and os.path.exists(os.path.join(var.rd_backup)):
        try:
            xbmcvfs.copy(os.path.join(var.fenlt_settings_db), os.path.join(var.rd_backup_fenlt))
        except:
            pass

#Delete RD Backup
def delete_fenlt_rd():
    if os.path.exists(os.path.join(var.rd_backup_fenlt)):
        try:
            os.unlink(os.path.join(var.rd_backup_fenlt))
        except OSError:
            pass


#Fen Light PM
def connect_fenlt_pm(conn, setting):
    try:
        # Update settings database
        pm_enable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        pm_token = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        pm_account_id = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(pm_enable, setting)
        cur.execute(pm_token, setting)
        cur.execute(pm_account_id, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
#Restore PM
def restore_fenlt_pm():
    try:
        conn_p = create_conn(var.pm_backup_fenlt)
        conn_t = create_conn(var.fenlt_settings_db)

        cur_p = conn_p.cursor()
        cur_t = conn_t.cursor()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('pm.enabled',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'pm.enabled',))

        conn_t.commit()
        
        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('pm.token',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'pm.token',))

        conn_t.commit()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('pm.account_id',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'pm.account_id',))

        conn_t.commit()
        cur_t.close()
        cur_p.close()
    except:
        pass
    
#Revoke PM
def revoke_fenlt_pm():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            connect_fenlt_pm(conn, ('empty_setting', 'pm.enabled'))
            connect_fenlt_pm(conn, ('empty_setting', 'pm.token'))
            connect_fenlt_pm(conn, ('empty_setting', 'pm.account_id'))
    except:
        pass
    
#Backup PM
def backup_fenlt_pm():
    if os.path.exists(os.path.join(var.fenlt_settings_db)) and os.path.exists(os.path.join(var.pm_backup)):
        try:
            xbmcvfs.copy(os.path.join(var.fenlt_settings_db), os.path.join(var.pm_backup_fenlt))
        except:
            pass

#Delete PM Backup
def delete_fenlt_pm():
    if os.path.exists(os.path.join(var.pm_backup_fenlt)):
        try:
            os.unlink(os.path.join(var.pm_backup_fenlt))
        except OSError:
            pass


#Fen Light AD
def connect_fenlt_ad(conn, setting):
    try:
        # Update settings database
        ad_enable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        ad_token = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        ad_account_id = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(ad_enable, setting)
        cur.execute(ad_token, setting)
        cur.execute(ad_account_id, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
#Restore AD
def restore_fenlt_ad():
    try:
        conn_p = create_conn(var.ad_backup_fenlt)
        conn_t = create_conn(var.fenlt_settings_db)

        cur_p = conn_p.cursor()
        cur_t = conn_t.cursor()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('ad.enabled',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'ad.enabled',))

        conn_t.commit()
        
        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('ad.token',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'ad.token',))

        conn_t.commit()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('ad.account_id',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'ad.account_id',))

        conn_t.commit()
        cur_t.close()
        cur_p.close()
    except:
        pass
    
#Revoke AD
def revoke_fenlt_ad():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            connect_fenlt_ad(conn, ('empty_setting', 'ad.enabled'))
            connect_fenlt_ad(conn, ('empty_setting', 'ad.token'))
            connect_fenlt_ad(conn, ('empty_setting', 'ad.account_id'))
    except:
        pass
    
#Backup AD
def backup_fenlt_ad():
    if os.path.exists(os.path.join(var.fenlt_settings_db)) and os.path.exists(os.path.join(var.ad_backup)):
        try:
            xbmcvfs.copy(os.path.join(var.fenlt_settings_db), os.path.join(var.ad_backup_fenlt))
        except:
            pass

#Delete AD Backup
def delete_fenlt_ad():
    if os.path.exists(os.path.join(var.ad_backup_fenlt)):
        try:
            os.unlink(os.path.join(var.ad_backup_fenlt))
        except OSError:
            pass



#Fen Light Trakt
def connect_fenlt_trakt(conn, setting):
    try:
        # Update settings database
        trakt_token = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        trakt_user = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        trakt_refresh = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        trakt_expires = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        trakt_watched_indicators = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(trakt_token, setting)
        cur.execute(trakt_user, setting)
        cur.execute(trakt_refresh, setting)
        cur.execute(trakt_expires, setting)
        cur.execute(trakt_watched_indicators, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
#Restore Trakt
def restore_fenlt_trakt():
    try:
        conn_p = create_conn(var.trakt_backup_fenlt)
        conn_t = create_conn(var.fenlt_settings_db)

        cur_p = conn_p.cursor()
        cur_t = conn_t.cursor()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('trakt.token',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'trakt.token',))

        conn_t.commit()
        
        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('trakt.user',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'trakt.user',))

        conn_t.commit()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('trakt.refresh',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'trakt.refresh',))

        conn_t.commit()
        
        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('trakt.expires',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'trakt.expires',))

        conn_t.commit()
        cur_t.close()
        cur_p.close()
    except:
        pass
    
#Revoke Trakt
def revoke_fenlt_trakt():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            connect_fenlt_trakt(conn, ('empty_setting', 'trakt.token'))
            connect_fenlt_trakt(conn, ('empty_setting', 'trakt.user'))
            connect_fenlt_trakt(conn, ('empty_setting', 'trakt.refresh'))
            connect_fenlt_trakt(conn, ('empty_setting', 'trakt.expires'))
            connect_fenlt_trakt(conn, (0, 'watched_indicators'))
    except:
        pass
    
#Backup Trakt
def backup_fenlt_trakt():
    if os.path.exists(os.path.join(var.fenlt_settings_db)) and os.path.exists(os.path.join(var.trakt_backup)):
        try:
            xbmcvfs.copy(os.path.join(var.fenlt_settings_db), os.path.join(var.trakt_backup_fenlt))
        except:
            pass

#Delete Trakt Backup
def delete_fenlt_trakt():
    if os.path.exists(os.path.join(var.trakt_backup_fenlt)):
        try:
            os.unlink(os.path.join(var.trakt_backup_fenlt))
        except OSError:
            pass
        

#Fen Light Easynews
def connect_fenlt_easy(conn, setting):
    try:
        # Update settings database
        easy_enable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        easy_user = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        easy_pass = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(easy_enable, setting)
        cur.execute(easy_user, setting)
        cur.execute(easy_pass, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
#Restore Easynews
def restore_fenlt_easy():
    try:
        conn_p = create_conn(var.easy_backup_fenlt)
        conn_t = create_conn(var.fenlt_settings_db)

        cur_p = conn_p.cursor()
        cur_t = conn_t.cursor()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('provider.easynews',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'provider.easynews',))

        conn_t.commit()
        
        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('easynews_user',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'easynews_user',))

        conn_t.commit()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('easynews_password',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'easynews_password',))

        conn_t.commit()
        cur_t.close()
        cur_p.close()
    except:
        pass
    
#Revoke Easynews
def revoke_fenlt_easy():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            connect_fenlt_trakt(conn, ('empty_setting', 'provider.easynews'))
            connect_fenlt_trakt(conn, ('empty_setting', 'easynews_user'))
            connect_fenlt_trakt(conn, ('empty_setting', 'easynews_password'))
    except:
        pass
    
#Backup Easynews
def backup_fenlt_easy():
    if os.path.exists(os.path.join(var.fenlt_settings_db)) and os.path.exists(os.path.join(var.non_backup)):
        try:
            xbmcvfs.copy(os.path.join(var.fenlt_settings_db), os.path.join(var.easy_backup_fenlt))
        except:
            pass

#Delete Easynews Backup
def delete_fenlt_easy():
    if os.path.exists(os.path.join(var.easy_backup_fenlt)):
        try:
            os.unlink(os.path.join(var.easy_backup_fenlt))
        except OSError:
            pass
        

#Fen Light Metadata
def connect_fenlt_meta(conn, setting):
    try:
        # Update settings database
        omdb_api = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(omdb_api, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
#Restore Metadat
def restore_fenlt_meta():
    try:
        conn_p = create_conn(var.meta_backup_fenlt)
        conn_t = create_conn(var.fenlt_settings_db)

        cur_p = conn_p.cursor()
        cur_t = conn_t.cursor()

        cur_p.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('omdb_api',))
        data = cur_p.fetchone()
        data_set = str(data)
        
        for char in char_remov:
            data_set = data_set.replace(char, "")
            cur_t.execute('''UPDATE settings SET setting_value = ? WHERE setting_id = ?''', (data_set, 'omdb_api',))

        conn_t.commit()
        cur_t.close()
        cur_p.close()
    except:
        pass
    
#Revoke Metadata
def revoke_fenlt_meta():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            connect_fenlt_trakt(conn, ('empty_setting', 'omdb_api'))
    except:
        pass
    
#Backup Metadata
def backup_fenlt_meta():
    if os.path.exists(os.path.join(var.fenlt_settings_db)) and os.path.exists(os.path.join(var.meta_backup)):
        try:
            xbmcvfs.copy(os.path.join(var.fenlt_settings_db), os.path.join(var.meta_backup_fenlt))
        except:
            pass

#Delete Metadata Backup
def delete_fenlt_meta():
    if os.path.exists(os.path.join(var.meta_backup_fenlt)):
        try:
            os.unlink(os.path.join(var.meta_backup_fenlt))
        except OSError:
            pass
