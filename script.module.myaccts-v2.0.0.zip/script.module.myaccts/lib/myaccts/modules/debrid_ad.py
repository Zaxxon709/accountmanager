import xbmc, xbmcaddon
import xbmcvfs
from pathlib import Path
from myaccts.modules import control

check_myaccts = xbmcaddon.Addon('script.module.myaccts').getSetting("alldebrid.token")

#Seren AD
def serenad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/')
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.seren/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file): #Check that the addon is installed and settings.xml exists
                
                check_seren = xbmcaddon.Addon('plugin.video.seren').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_seren): #Compare Account Mananger token to Add-on token. If they match authorization is skipped

                        #Write debrid data to the add-ons settings.xml
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")

                        addon = xbmcaddon.Addon("plugin.video.seren")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        enabled_rd = ("false")
                        addon.setSetting("realdebrid.enabled", enabled_rd)

                        enabled_pm = ("false")
                        addon.setSetting("premiumize.enabled", enabled_pm)

                        enabled_ad = ("true")
                        addon.setSetting("alldebrid.enabled", enabled_ad)

#Ezra AD
def ezraad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.ezra/')
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ezra/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_ezra = xbmcaddon.Addon('plugin.video.ezra').getSetting("ad.token")

                if str(check_myaccts) != str(check_ezra):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.ezra")
                        addon.setSetting("ad.account_id", your_username)
                        addon.setSetting("ad.token", your_token)


#Fen AD
def fenad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.fen/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_fen = xbmcaddon.Addon('plugin.video.fen').getSetting("ad.token")

                if str(check_myaccts) != str(check_fen):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.fen")
                        addon.setSetting("ad.account_id", your_username)
                        addon.setSetting("ad.token", your_token)


#POV AD
def povad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.pov/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("ad.token")

                if str(check_myaccts) != str(check_pov):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.pov")
                        addon.setSetting("ad.account_id", your_username)
                        addon.setSetting("ad.token", your_token)
                

#Umbrella AD
def umbad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.umbrella/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("alldebridtoken")

                if str(check_myaccts) != str(check_umb):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.umbrella")
                        addon.setSetting("alldebridusername", your_username)
                        addon.setSetting("alldebridtoken", your_token)


#Shadow AD
def shadowad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.shadow/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.shadow/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_shadow = xbmcaddon.Addon('plugin.video.shadow').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_shadow):
                
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.shadow")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        rd_use = ("false")
                        addon.setSetting("debrid_use_rd", rd_use)

                        pm_use = ("false")
                        addon.setSetting("debrid_use_pm", pm_use)

                        ad_use = ("true")
                        addon.setSetting("debrid_use_ad", ad_use)

                
#Ghost AD
def ghostad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.ghost/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ghost/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_ghost = xbmcaddon.Addon('plugin.video.ghost').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_ghost):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                        
                        addon = xbmcaddon.Addon("plugin.video.ghost")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        rd_use = ("false")
                        addon.setSetting("debrid_use_rd", rd_use)

                        pm_use = ("false")
                        addon.setSetting("debrid_use_pm", pm_use)

                        ad_use = ("true")
                        addon.setSetting("debrid_use_ad", ad_use)


#Unleashed AD
def unleashedad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.unleashed/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.unleashed/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_unleashed = xbmcaddon.Addon('plugin.video.unleashed').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_unleashed):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.unleashed")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Chains AD
def chainsad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.thechains/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.thechains/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_chains = xbmcaddon.Addon('plugin.video.thechains').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_chains):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.thechains")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Moria AD
def moriaad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.moria/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.moria/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_moria = xbmcaddon.Addon('plugin.video.moria').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_moria):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.moria")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Base 19 AD
def basead_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.base19/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.base19/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_base = xbmcaddon.Addon('plugin.video.base19').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_base):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.base19")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Twisted AD
def twistedad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.twisted/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.twisted/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_twisted = xbmcaddon.Addon('plugin.video.twisted').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_twisted):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.twisted")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Magic Dragon AD
def mdad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.magicdragon/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.magicdragon/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_md = xbmcaddon.Addon('plugin.video.magicdragon').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_md):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.magicdragon")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Asgard AD
def asgardad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.asgard/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.asgard/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_asgard = xbmcaddon.Addon('plugin.video.asgard').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_asgard):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.asgard")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#M.E.T.V AD
def metvad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/plugin.video.metv19/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.metv19/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_metv = xbmcaddon.Addon('plugin.video.metv19').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_metv):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.metv19")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#ResolveURL AD
def rurlad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/script.module.resolveurl/')        
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ghost/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_rurl = xbmcaddon.Addon('script.module.resolveurl').getSetting("AllDebridResolver_token")

                if str(check_myaccts) != str(check_rurl):
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("script.module.resolveurl")
                        addon.setSetting("AllDebridResolver_client_id", your_username)
                        addon.setSetting("AllDebridResolver_token", your_token)

                        cache_only = ("true")
                        addon.setSetting("AllDebridResolver_cached_only", cache_only)


#My Accounts AD
def myaccountsad_auth():

        debrid_addon = xbmcvfs.translatePath('special://home/addons/script.module.myaccounts/')
        debrid_file = xbmcvfs.translatePath('special://userdata/addon_data/script.module.myaccounts/settings.xml')
        
        if xbmcvfs.exists(debrid_addon) and xbmcvfs.exists(debrid_file):
                
                check_myaccounts = xbmcaddon.Addon('script.module.myaccounts').getSetting("alldebrid.token")

                if str(check_myaccts) != str(check_myaccounts):
                
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("script.module.myaccounts")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)


def debrid_auth_ad(): #Sync all add-ons
        if str(check_myaccts) != '': #Check to make sure Account Manager is authorized
                serenad_auth()
                ezraad_auth()
                fenad_auth()
                povad_auth()
                umbad_auth()
                shadowad_auth()
                ghostad_auth()
                unleashedad_auth()
                chainsad_auth()
                moriaad_auth()
                basead_auth()
                twistedad_auth()
                mdad_auth()
                asgardad_auth()
                metvad_auth()
                rurlad_auth()
                myaccountsad_auth()
