# -*- coding: utf-8 -*-
"""
	Account Manager
"""
import re
import json
import time
import os.path
import requests
import xbmcaddon
from requests.adapters import HTTPAdapter
from libs.common import var
from accountmgr.modules import control
from accountmgr.modules import log_utils

joinPath = os.path.join
session = requests.Session()
session.mount('https://api.simkl.com', HTTPAdapter(max_retries=1, pool_maxsize=100))
addon_id = 'script.module.accountmgr'
addon = xbmcaddon.Addon(addon_id)
simkl_icon = joinPath(os.path.join(addon.getAddonInfo('path'), 'resources', 'icons'), 'simkl.png')

CLIENTID = var.client_am_sk
SECRET = var.secret_am_sk

class Simkl:
        def auth(self):
                self.token = ''
                url = 'https://api.simkl.com/oauth/pin?client_id=%s&redirect_uri=urn:ietf:wg:oauth:2.0:oob' % CLIENTID
                response = session.get(url).json()
                self.user_code = response['user_code']
                self.progressDialog = control.progressDialog
                self.progressDialog.create('Simkl Authorization')
                self.progressDialog.update(-1, control.progress_line % (control.lang(32513) % 'https://simkl.com/pin/', control.lang(32514) % self.user_code, ''))
                self.timeout = int(response['interval'])
                while self.token == '':
                        if self.progressDialog.iscanceled():
                                self.progressDialog.close()
                                break
                        self.get_token()
                if self.token:
                        self.set_auth()

        def get_token(self):
                control.sleep(self.timeout*1000)
                url = 'https://api.simkl.com/oauth/pin/%s?client_id=%s&redirect_uri=urn:ietf:wg:oauth:2.0:oob' % (self.user_code, CLIENTID)
                response = session.get(url)
                if response.status_code == 200:
                        responseJson = response.json()
                        if responseJson.get('result') == 'KO':
                                return #
                        else:
                                try:
                                        self.progressDialog.close()
                                        self.token = responseJson['access_token']
                                except:
                                        control.notification(message="Simkl Authorization Failed", icon=simkl_icon)
                else:
                        return
        
        def set_auth(self):
                control.sleep(1000)
                headers = {
                    "Authorization": 'Bearer {0}'.format(self.token),
                    "simkl-api-key": CLIENTID
                }
                response = session.get('https://api.simkl.com/users/settings', headers=headers)
                if response.status_code == 200:
                        responseJson = response.json()
                        username = str(responseJson['user']['name'])
                control.setSetting('simkl.username', username)
                control.setSetting('simkl.token', self.token)
                control.notification_simkl(title='Simkl', message='Simkl Successfully Authorized', icon=simkl_icon) #Authorization complete. Start sync process

        def revoke():
                control.setSetting('simkl.token', '')
                control.setSetting('simkl.username', '')
                control.setSetting('simkl.service', '')
                control.notification(message="Simkl Authorization Revoked", icon=simkl_icon)

        def extended_account_info(self):
                URL_USER = 'https://api.simkl.com/users/settings'
                token = control.setting('simkl.token')
                headers = {
                    "Authorization": 'Bearer {0}'.format(token),
                    "simkl-api-key": CLIENTID
                }
                response_user = session.get(URL_USER, headers=headers)
                if response_user.status_code == 200:
                        responseJson_user = response_user.json()
                        user_id = responseJson_user['account']['id']
                        account_info = responseJson_user

                URL_STATS = ('https://api.simkl.com/users/%s/stats' % user_id)
                response_stats = session.get(URL_STATS, headers=headers)
                if response_stats.status_code == 200:
                        responseJson_stats = response_stats.json()
                        stats = responseJson_stats
                return account_info, stats

        def account_info_to_dialog(self):
                from datetime import datetime, timedelta
                try:
                        account_info, stats = self.extended_account_info()
                        username = account_info['user']['name']
                        timezone = account_info['account']['timezone']
                        joined = control.jsondate_to_datetime(account_info['user']['joined_at'], "%Y-%m-%dT%H:%M:%fZ")

                        
                        total_minutes = stats['total_mins']
                        if total_minutes == 0: movies_tv_watched_minutes = ['0 days', '0:00:00']
                        elif total_minutes < 1440: movies_tv_watched_minutes = ['0 days', "{:0>8}".format(str(timedelta(minutes=total_minutes)))]
                        else: movies_tv_watched_minutes = ("{:0>8}".format(str(timedelta(minutes=total_minutes)))).split(', ')
                        movies_tv_watched_minutes = control.lang(40071) % (movies_tv_watched_minutes[0], movies_tv_watched_minutes[1].split(':')[0], movies_tv_watched_minutes[1].split(':')[1])
                        
                        movie_minutes = stats['movies']['total_mins']
                        if movie_minutes == 0: movies_watched_minutes = ['0 days', '0:00:00']
                        elif movie_minutes < 1440: movies_watched_minutes = ['0 days', "{:0>8}".format(str(timedelta(minutes=movie_minutes)))]
                        else: movies_watched_minutes = ("{:0>8}".format(str(timedelta(minutes=movie_minutes)))).split(', ')
                        movies_watched_minutes = control.lang(40071) % (movies_watched_minutes[0], movies_watched_minutes[1].split(':')[0], movies_watched_minutes[1].split(':')[1])
                        
                        episode_minutes = stats['tv']['total_mins']
                        if episode_minutes == 0: episodes_watched_minutes = ['0 days', '0:00:00']
                        elif episode_minutes < 1440: episodes_watched_minutes = ['0 days', "{:0>8}".format(str(timedelta(minutes=episode_minutes)))]
                        else: episodes_watched_minutes = ("{:0>8}".format(str(timedelta(minutes=episode_minutes)))).split(', ')
                        episodes_watched_minutes = control.lang(40071) % (episodes_watched_minutes[0], episodes_watched_minutes[1].split(':')[0], episodes_watched_minutes[1].split(':')[1])
                        
                        heading = 'Simkl'
                        items = []
                        items += [control.lang(40036) % username]
                        items += [control.lang(40063) % timezone]
                        items += [control.lang(40064) % joined]
                        items += [control.lang(40112) % (movies_tv_watched_minutes)]
                        items += [control.lang(40113) % (movies_watched_minutes)]
                        items += [control.lang(40114) % (episodes_watched_minutes)]
                        return control.selectDialog(items, heading)
                except:
                        xbmc.log('%s: Simkl.py Account Info Failed!' % var.amgr, xbmc.LOGINFO)
                        pass
                        
