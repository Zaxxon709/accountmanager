import xbmc, xbmcaddon
import xbmcvfs
from pathlib import Path
from myaccts.modules import control
from myaccts.modules import var

#Seren AD
def serenad_auth():

        if xbmcvfs.exists(var.check_addon_seren) and xbmcvfs.exists(var.check_seren_settings): #Check that the addon is installed and settings.xml exists
                check_seren = xbmcaddon.Addon('plugin.video.seren').getSetting("alldebrid.apikey")
                check_seren_rd = xbmcaddon.Addon('plugin.video.seren').getSetting("rd.auth")
                check_seren_pm = xbmcaddon.Addon('plugin.video.seren').getSetting("premiumize.token")
                if not str(var.check_myaccts_ad) == str(check_seren) or str(check_seren) == '': #Compare Account Mananger token to Add-on token. If they match authorization is skipped

                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                        
                        #Write debrid data to settings.xml
                        addon = xbmcaddon.Addon("plugin.video.seren")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.apikey", your_token)

                        premium_stat = ("Premium")
                        addon.setSetting("alldebrid.premiumstatus", premium_stat)
                        
                        #Set enabled for authorized debrid services
                        enabled_ad = ("true")
                        addon.setSetting("alldebrid.enabled", enabled_ad)

                        if str(check_seren_rd) != '': #Check if add-on is authorized
                                enabled_rd = ("true")
                                addon.setSetting("realdebrid.enabled", enabled_rd)
                        else:
                                enabled_rd = ("false")
                                addon.setSetting("realdebrid.enabled", enabled_rd)
                
                        if str(check_seren_pm) != '': #Check if add-on is authorized
                                enabled_pm = ("true")
                                addon.setSetting("premiumize.enabled", enabled_pm)
                        else:
                                enabled_pm = ("false")
                                addon.setSetting("premiumize.enabled", enabled_pm)

#Ezra AD
def ezraad_auth():

        if xbmcvfs.exists(var.check_addon_ezra) and xbmcvfs.exists(var.check_ezra_settings):
                check_ezra = xbmcaddon.Addon('plugin.video.ezra').getSetting("ad.token")
                check_ezra_rd = xbmcaddon.Addon('plugin.video.ezra').getSetting("rd.token")
                check_ezra_pm = xbmcaddon.Addon('plugin.video.ezra').getSetting("pm.token")
                if not str(var.check_myaccts_ad) == str(check_ezra) or str(check_ezra) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.ezra")
                        addon.setSetting("ad.account_id", your_username)
                        addon.setSetting("ad.token", your_token)

                        enabled_ad = ("true")
                        addon.setSetting("ad.enabled", enabled_ad)

                        if str(check_ezra_rd) != '':
                                enabled_rd = ("true")
                                addon.setSetting("rd.enabled", enabled_rd)
                        else:
                                enabled_rd = ("false")
                                addon.setSetting("rd.enabled", enabled_rd)
                
                        if str(check_ezra_pm) != '':
                                enabled_pm = ("true")
                                addon.setSetting("pm.enabled", enabled_pm)
                        else:
                                enabled_pm = ("false")
                                addon.setSetting("pm.enabled", enabled_pm)


#Fen AD
def fenad_auth():

        if xbmcvfs.exists(var.check_addon_fen) and xbmcvfs.exists(var.check_fen_settings):
                check_fen = xbmcaddon.Addon('plugin.video.fen').getSetting("ad.token")
                check_fen_rd = xbmcaddon.Addon('plugin.video.fen').getSetting("rd.token")
                check_fen_pm = xbmcaddon.Addon('plugin.video.fen').getSetting("pm.token")
                if not str(var.check_myaccts_ad) == str(check_fen) or str(check_fen) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.fen")
                        addon.setSetting("ad.account_id", your_username)
                        addon.setSetting("ad.token", your_token)

                        enabled_ad = ("true")
                        addon.setSetting("ad.enabled", enabled_ad)

                        if str(check_fen_rd) != '':
                                enabled_rd = ("true")
                                addon.setSetting("rd.enabled", enabled_rd)
                        else:
                                enabled_rd = ("false")
                                addon.setSetting("rd.enabled", enabled_rd)
                
                        if str(check_fen_pm) != '':
                                enabled_pm = ("true")
                                addon.setSetting("pm.enabled", enabled_pm)
                        else:
                                enabled_pm = ("false")
                                addon.setSetting("pm.enabled", enabled_pm)


#POV AD
def povad_auth():

        if xbmcvfs.exists(var.check_addon_pov) and xbmcvfs.exists(var.check_pov_settings):
                check_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("ad.token")
                check_pov_rd = xbmcaddon.Addon('plugin.video.pov').getSetting("rd.token")
                check_pov_pm = xbmcaddon.Addon('plugin.video.pov').getSetting("pm.token")
                if not str(var.check_myaccts_ad) == str(check_pov) or str(check_pov) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.pov")
                        addon.setSetting("ad.account_id", your_username)
                        addon.setSetting("ad.token", your_token)

                        enabled_ad = ("true")
                        addon.setSetting("ad.enabled", enabled_ad)

                        if str(check_pov_rd) != '':
                                enabled_rd = ("true")
                                addon.setSetting("rd.enabled", enabled_rd)
                        else:
                                enabled_rd = ("false")
                                addon.setSetting("rd.enabled", enabled_rd)
                
                        if str(check_pov_pm) != '':
                                enabled_pm = ("true")
                                addon.setSetting("pm.enabled", enabled_pm)
                        else:
                                enabled_pm = ("false")
                                addon.setSetting("pm.enabled", enabled_pm)
                

#Umbrella AD
def umbad_auth():

        if xbmcvfs.exists(var.check_addon_umb) and xbmcvfs.exists(var.check_umb_settings):
                check_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("alldebridtoken")
                check_umb_rd = xbmcaddon.Addon('plugin.video.umbrella').getSetting("realdebridtoken")
                check_umb_pm = xbmcaddon.Addon('plugin.video.umbrella').getSetting("premiumizetoken")
                if not str(var.check_myaccts_ad) == str(check_umb) or str(check_umb) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.umbrella")
                        addon.setSetting("alldebridusername", your_username)
                        addon.setSetting("alldebridtoken", your_token)

                        enabled_ad = ("true")
                        addon.setSetting("alldebrid.enabled", enabled_ad)

                        if str(check_umb_rd) != '':
                                enabled_rd = ("true")
                                addon.setSetting("alldebrid.enabled", enabled_rd)
                        else:
                                enabled_rd = ("false")
                                addon.setSetting("realdebrid.enabled", enabled_rd)
                
                        if str(check_umb_pm) != '':
                                enabled_pm = ("true")
                                addon.setSetting("premiumize.enabled", enabled_pm)
                        else:
                                enabled_pm = ("false")
                                addon.setSetting("premiumize.enabled", enabled_pm)


#Shadow AD
def shadowad_auth():

        if xbmcvfs.exists(var.check_addon_shadow) and xbmcvfs.exists(var.check_shadow_settings):
                check_shadow = xbmcaddon.Addon('plugin.video.shadow').getSetting("alldebrid.token")
                check_shadow_rd = xbmcaddon.Addon('plugin.video.shadow').getSetting("rd.auth")
                check_shadow_pm = xbmcaddon.Addon('plugin.video.shadow').getSetting("premiumize.token")
                if not str(var.check_myaccts_ad) == str(check_shadow) or str(check_shadow) == '':
                
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.shadow")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        enabled_ad = ("true")
                        addon.setSetting("debrid_use_ad", enabled_ad)

                        if str(check_shadow_rd) != '':
                                rd_use = ("true")
                                addon.setSetting("debrid_use_rd", rd_use)
                        else:
                                rd_use = ("false")
                                addon.setSetting("debrid_use_rd", rd_use)
                
                        if str(check_shadow_pm) != '':
                                pm_use = ("true")
                                addon.setSetting("debrid_use_pm", pm_use)
                        else:
                                pm_use = ("false")
                                addon.setSetting("debrid_use_pm", pm_use)

                
#Ghost AD
def ghostad_auth():

        if xbmcvfs.exists(var.check_addon_ghost) and xbmcvfs.exists(var.check_ghost_settings):
                check_ghost = xbmcaddon.Addon('plugin.video.ghost').getSetting("alldebrid.token")
                if not str(var.check_myaccts_ad) == str(check_ghost) or str(check_ghost) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                        
                        addon = xbmcaddon.Addon("plugin.video.ghost")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)

#Unleashed AD
def unleashedad_auth():

        if xbmcvfs.exists(var.check_addon_unleashed) and xbmcvfs.exists(var.check_unleashed_settings):
                check_unleashed = xbmcaddon.Addon('plugin.video.unleashed').getSetting("alldebrid.token")
                if not str(var.check_myaccts_ad) == str(check_unleashed) or str(check_unleashed) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.unleashed")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Chains AD
def chainsad_auth():

        if xbmcvfs.exists(var.check_addon_chains) and xbmcvfs.exists(var.check_chains_settings):
                check_thechains = xbmcaddon.Addon('plugin.video.thechains').getSetting("alldebrid.token")
                if not str(var.check_myaccts_ad) == str(check_chains) or str(check_chains) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.thechains")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Moria AD
def moriaad_auth():

        if xbmcvfs.exists(var.check_addon_moria) and xbmcvfs.exists(var.check_moria_settings):
                check_moria = xbmcaddon.Addon('plugin.video.moria').getSetting("alldebrid.token")
                if not str(var.check_myaccts_ad) == str(check_moria) or str(check_moria) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.moria")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Base 19 AD
def basead_auth():

        if xbmcvfs.exists(var.check_addon_base) and xbmcvfs.exists(var.check_base_settings):
                check_base = xbmcaddon.Addon('plugin.video.base19').getSetting("alldebrid.token")
                if not str(var.check_myaccts_ad) == str(check_base) or str(check_base) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.base19")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Twisted AD
def twistedad_auth():

        if xbmcvfs.exists(var.check_addon_twisted) and xbmcvfs.exists(var.check_twisted_settings):
                check_twisted = xbmcaddon.Addon('plugin.video.twisted').getSetting("alldebrid.token")
                if not str(var.check_myaccts_ad) == str(check_twisted) or str(check_twisted) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.twisted")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Magic Dragon AD
def mdad_auth():

        if xbmcvfs.exists(var.check_addon_md) and xbmcvfs.exists(var.check_md_settings):
                check_md = xbmcaddon.Addon('plugin.video.magicdragon').getSetting("alldebrid.token")
                if not str(var.check_myaccts_ad) == str(check_md) or str(check_md) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.magicdragon")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#Asgard AD
def asgardad_auth():

        if xbmcvfs.exists(var.check_addon_asgard) and xbmcvfs.exists(var.check_asgard_settings):
                check_asgard = xbmcaddon.Addon('plugin.video.asgard').getSetting("alldebrid.token")
                if not str(var.check_myaccts_ad) == str(check_asgard) or str(check_asgard) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.asgard")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#M.E.T.V AD
def metvad_auth():

        if xbmcvfs.exists(var.check_addon_metv) and xbmcvfs.exists(var.check_metv_settings):
                check_metv = xbmcaddon.Addon('plugin.video.metv19').getSetting("alldebrid.token")
                if not str(var.check_myaccts_ad) == str(check_metv) or str(check_metv) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("plugin.video.metv19")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)

                        d_select = ("2")
                        addon.setSetting("debrid_select", d_select)


#ResolveURL AD
def rurlad_auth():

        if xbmcvfs.exists(var.check_addon_rurl) and xbmcvfs.exists(var.check_rurl_settings):
                check_rurl = xbmcaddon.Addon('script.module.resolveurl').getSetting("AllDebridResolver_token")
                if not str(var.check_myaccts_ad) == str(check_rurl) or str(check_rurl) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("script.module.resolveurl")
                        addon.setSetting("AllDebridResolver_client_id", your_username)
                        addon.setSetting("AllDebridResolver_token", your_token)

                        cache_only = ("true")
                        addon.setSetting("AllDebridResolver_cached_only", cache_only)


#My Accounts AD
def myaccountsad_auth():

        if xbmcvfs.exists(var.check_addon_myaccounts) and xbmcvfs.exists(var.check_myaccounts_settings):
                check_myaccounts = xbmcaddon.Addon('script.module.myaccounts').getSetting("alldebrid.token")
                if not str(var.check_myaccts_ad) == str(check_myaccounts) or str(check_myaccounts) == '':
                
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("alldebrid.username")
                        your_token = myaccts.getSetting("alldebrid.token")
                
                        addon = xbmcaddon.Addon("script.module.myaccounts")
                        addon.setSetting("alldebrid.username", your_username)
                        addon.setSetting("alldebrid.token", your_token)


def debrid_auth_ad(): #Sync all add-ons
                serenad_auth()
                ezraad_auth()
                fenad_auth()
                povad_auth()
                umbad_auth()
                shadowad_auth()
                ghostad_auth()
                unleashedad_auth()
                chainsad_auth()
                moriaad_auth()
                basead_auth()
                twistedad_auth()
                mdad_auth()
                asgardad_auth()
                metvad_auth()
                rurlad_auth()
                myaccountsad_auth()
